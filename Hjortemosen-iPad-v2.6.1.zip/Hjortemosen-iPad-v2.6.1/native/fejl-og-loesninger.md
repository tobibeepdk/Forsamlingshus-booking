# Native fejl og afprøvede løsninger

## Buildmiljø · ikke en produktionsfejl

### Xcode kunne ikke kontakte CoreSimulator i sandbox

Symptom: `actool`/Xcode rapporterede manglende simulator-runtimes og afvist forbindelse til CoreSimulatorService, selvom iOS 27-runtimen fandtes uden for sandboxen.
Årsag: Begrænset adgang til Xcodes systemtjeneste. Sikkerhed: høj; compiler og SDK blev fundet, mens tjenesteforbindelsen blev afvist.
Løsning: Byg det autoriserede lokale projekt med godkendt sandbox-eskalering. Dette starter ikke en simulator og ændrer ingen udviklerkonto.
Forebyggelse: Skeln mellem SDK-typecheck, gennemført build og faktisk WKWebView-forløb på simulator/enhed. En afbrudt build er ikke et bestået resultat.

### Forkert Swift-overload til async JavaScript

Symptom: `extra trailing closure passed in call` ved `callAsyncJavaScript`.
Årsag: Completion-overload bruger to `in:`-labels; `contentWorld:` vælger Swift async-overload uden completion-closure. Sikkerhed: høj; den installerede WebKit.swiftinterface viste begge signaturer.
Løsning: Brug `callAsyncJavaScript(..., in: nil, in: .page) { result in ... }`, så JavaScript-Promises faktisk afventes før den native baggrundsopgave afsluttes.
Forebyggelse: Kontroller den installerede SDK-interface ved overload-fejl frem for at fjerne Promise-afventning.

## Scope

Filprøver bruger rigtige, midlertidige macOS-filer og validerer fulde JSON-kopier, signaturstreger, fejlbeskyttelse, historik og genåbning. De beviser ikke Mail/Beskeder, Files UI eller lagerbevarelse efter sletning på en fysisk iPad. Native appens øvrige QA dokumenteres i udgivelsens valideringsrapport.

## Fundet ved review før udgivelse

En eksisterende backup med ugyldig UTF-8 blev behandlet som en manglende fil. Løsningen afviser læsning og gemning tydeligt, så bytes bevares. En rigtig fil med `ff fe 80` reproducerede fejlen i native filprøven før rettelsen og består efter.

WKWebView uden en implementeret JavaScript confirm-delegate vælger Cancel som standard. Appens sletning og erstatningsimport kræver derfor en native bekræftelsesdialog. Implementationen kontrollerer oprindelsesrammen og viser Ja/Annuller. Den installerede API-deklaration og WebKits officielle header bekræfter standardadfærden; faktisk native import/sletning skal afprøves i simulator-QA før fuld funktionalitet hævdes.

### UIScene-livscyklus i Xcode 27

Symptom: Den tidligere AppDelegate-opstart med en løs UIWindow blev afvist af den aktuelle iOS 27-runtime.
Årsag: Appen havde ingen UIScene-konfiguration. Sikkerhed: høj; den kendte opstartsfejl og den gamle AppDelegate viste samme manglende livscyklus.
Løsning: En enkelt UIWindowScene med offentlig SceneDelegate og scene-manifest. SceneDelegate sender både tab af fokus og baggrund til den eksisterende async gemning.
Forebyggelse: Test faktisk opstart i den aktuelle runtime; et vellykket build alene beviser ikke livscyklussen.
Bevis: 2.6.1/build 261 bygges til simulator og iPad-enhed; det gennemspillede forløb og faktisk backup dokumenteres separat i udgivelsens native QA.

### Samtidige gemninger ved tab af fokus og baggrund · fundet ved review

Symptom: Første afsluttede flush kunne afslutte den fælles UIKit-baggrundsopgave, mens en senere flush stadig ventede på IndexedDB og filskrivning.
Årsag: To scene-callbacks delte ét task-ID uden at tælle ventende arbejde. Sikkerhed: høj for koderacen; datatab ved tvangslukning er ikke reproduceret.
Løsning: Tæl ventende flush-callbacks på hovedtråden. Afslut først efter den sidste async JavaScript-callback og dens barriere på native skrivekøen. iPadOS' udløbshandler afslutter stadig ubetinget.
Forebyggelse: En barriere på filkøen dækker kun allerede indsendt arbejde; den dækker ikke en senere JavaScript-gemning, som endnu ikke har nået køen.
Bevis: Uafhængigt review af saveOpenForms(), backupManager.flush(), HjortNative.flush() og native callbacks. De faktiske simulatorforløb er gemt i udgivelsens QA; de er ikke en reproduktion af tvangslukning midt i racen.

## Filadgang · miljøproblem, ikke en produktionsfejl

### iCloud-pladsholdere blokerede læsning og Xcode-opstart

Symptom: cp/Python-læsninger stoppede på kildefiler; Xcode stoppede før kompilering i NSFileCoordinator. ls -lO viste compressed,dataless på de berørte filer.
Årsag: Projektets Documents-filer var iCloud-pladsholdere. Sikkerhed: høj; stack-sample viste koordineret læsning, og en afgrænset download gjorde den samme fil læsbar.
Løsning: Hent kun den nødvendige eksisterende fil med /usr/bin/brctl download /absolut/filsti uden for sandboxen. Byg en lokal kopi under /private/tmp, og sammenlign SHA-256 for kilder og de 21 tilladte webassets.
Forebyggelse: Undersøg dataless-flag og filadgang før gentagne compiler-/testforsøg. Skift ikke produktionskode for en læsning, der er blokeret i filprovider. Kopiér ikke hele Documents eller buildhistorik.
Bevis: BackupStore.swift kunne kopieres efter den konkrete download. 15 native filer matchede byggekopien; begge 2.6.1-builds bestod, og begge bundles matchede alle 21 webasset-hashes. Stack-samples, buildlogs og hash-manifester ligger i native QA.

### Simulatorens testmanager stoppede før app-testen · ukendt OS-årsag

Symptom: Xcode færdigbyggede UI-testtarget, men skrev ingen Test Suite/Test Case. QA-simulatorens xpcproxy_sim for com.apple.testmanagerd blev i U-tilstand; stack-sample viste dyld preflight af delt cache efterfulgt af mmap. Samme symptom gentog sig efter én ren shutdown/boot af den samme QA-simulator med alle data bevaret.
Årsag: Ukendt. Sikkerhed: høj for placeringen før app-testen, lav for selve OS-årsagen. SDK-runtime er et lokalt, forseglet, read-only APFS-image; de to cachefiler var fuldt allokerede uden dataless-flag. Små header-/slutlæsninger og en 4 KiB læsemapping lykkedes; det beviser ikke en fuld eksekverbar mapping.
Afprøvet løsning: Én normal QA-simulatorgenstart løste ikke stoppet. Forsøgene blev afsluttet målrettet uden ændringer af produktkode, cachefiler, Apple-konti eller andre simulatorer.
Forebyggelse: Hæv ikke WKWebView-, UIKit- eller Files-flow som bestået, når ingen app-test blev kørt. Revalider testmiljøet før et senere forløb; gennemfør derefter både UI-test og inspektion af den faktiske JSON.
Bevis: To processamples, to Xcode-testlogs og en bootlog i outputs/hjortemosen-v2.6.1/qa/native. Der blev kørt nul app-tests. Filinspektion af den dedikerede QA-simulator fandt ingen matchende Hjortemosen-datacontainer og dermed ingen afsluttende QA-backup. Simulator- og device-builds samt 18 Swift-filprøver består uafhængigt af dette miljøproblem.
