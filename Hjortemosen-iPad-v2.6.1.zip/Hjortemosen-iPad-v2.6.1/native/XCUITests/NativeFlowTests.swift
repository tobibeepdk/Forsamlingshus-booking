import XCTest

final class NativeFlowTests: XCTestCase {
    func testAutomaticFilesBackupAndDraftSurviveRelaunch() throws {
        continueAfterFailure = false
        let app = XCUIApplication(bundleIdentifier: "dk.hjortemosen.booking")
        app.launch()
        XCTAssertTrue(app.webViews.firstMatch.waitForExistence(timeout: 30), "Bundled app loads in real WKWebView")
        let newBooking = app.buttons["Ny booking"].firstMatch
        XCTAssertTrue(newBooking.waitForExistence(timeout: 30), app.debugDescription)
        newBooking.tap()
        let name = app.textFields.allElementsBoundByIndex.first { $0.placeholderValue == "Lejerens fulde navn" }
        XCTAssertNotNil(name, app.debugDescription)
        name!.tap()
        name!.typeText("QA automatisk iPad")
        app.buttons["← Tilbage"].firstMatch.tap()
        let returnToDraft = app.buttons["Fortsæt kladden →"]
        XCTAssertTrue(returnToDraft.waitForExistence(timeout: 20), app.debugDescription)
        returnToDraft.tap()
        let afterBack = app.textFields.allElementsBoundByIndex.first { $0.placeholderValue == "Lejerens fulde navn" }
        XCTAssertEqual(afterBack?.value as? String, "QA automatisk iPad", "The visible back button preserves the real WKWebView draft")
        app.buttons["Mere"].firstMatch.tap()
        let backupSaved = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "Backupfil gemt:")).firstMatch
        XCTAssertTrue(backupSaved.waitForExistence(timeout: 30), app.debugDescription)
        let backup = XCTAttachment(screenshot: app.screenshot())
        backup.name = "Native automatic Files backup"
        backup.lifetime = .keepAlways
        add(backup)
        XCUIDevice.shared.press(.home)
        app.activate()
        app.terminate()
        app.launch()
        XCTAssertTrue(app.buttons["Ny booking"].firstMatch.waitForExistence(timeout: 30))
        let continueDraft = app.buttons["Fortsæt kladden →"]
        XCTAssertTrue(continueDraft.waitForExistence(timeout: 20), app.debugDescription)
        continueDraft.tap()
        let restored = app.textFields.allElementsBoundByIndex.first { $0.placeholderValue == "Lejerens fulde navn" }
        XCTAssertEqual(restored?.value as? String, "QA automatisk iPad", "Persistent WKWebView retains the original draft")
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "Native restored booking draft"
        screenshot.lifetime = .keepAlways
        add(screenshot)
        // Exercises a real app workflow that depends on JavaScript confirm().
        app.buttons["Ryd formular"].tap()
        XCTAssertTrue(app.alerts["Hjortemosen"].waitForExistence(timeout: 10), "Native confirm dialog must appear")
        let confirmation = XCTAttachment(screenshot: app.screenshot())
        confirmation.name = "Native UIKit confirmation Ja or Annuller"
        confirmation.lifetime = .keepAlways
        add(confirmation)
        app.alerts.buttons["Annuller"].tap()
        XCTAssertEqual(restored?.value as? String, "QA automatisk iPad", "Cancel preserves draft")
        app.buttons["Ryd formular"].tap()
        app.alerts.buttons["Ja, fortsæt"].tap()
        let cleared = app.textFields.allElementsBoundByIndex.first { $0.placeholderValue == "Lejerens fulde navn" }
        XCTAssertNotEqual(cleared?.value as? String, "QA automatisk iPad", "Confirm clears the draft")
        // Leave the durable full snapshot with a known final QA draft for file inspection.
        cleared!.tap()
        cleared!.typeText("QA automatisk iPad verificeret")
        app.buttons["Mere"].firstMatch.tap()
        XCTAssertTrue(backupSaved.waitForExistence(timeout: 30))
        XCUIDevice.shared.press(.home)
    }
}
