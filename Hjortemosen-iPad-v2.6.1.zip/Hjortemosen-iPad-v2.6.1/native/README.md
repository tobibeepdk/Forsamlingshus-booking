# Hjortemosen til iPad

Denne iPad-app indeholder hele bookingappen og virker uden internet. Bookinger, standardpriser, kladder, kontraktfelter og håndskrevne underskrifter gemmes i appen. Efter ændringer skriver den også automatisk en fuld JSON-backup i appens Documents-mappe:

`Hjortemosen/seneste-backup.json`

Mappen er synlig under appen i **Filer → På min iPad**. Op til ti tidligere versioner ligger ved siden af den seneste kopi. **Åbn backupmappe** viser iPadens dokumentvælger i mappen. Valg af en fil her importerer ikke automatisk indholdet; brug appens gendannelse/import til dette.

En backup markeres først som gemt, når filen er skrevet og synkroniseret til lageret. Ugyldige eller ufuldstændige kopier erstatter ikke en gyldig kopi. Hvis appens primære data pludselig mangler, bevares den tidligere backup. Appen forsøger at afslutte ventende gemning, når den går i baggrunden; en tvangslukning kan afbryde en ændring, der endnu ikke er færdig.

Hver iPad har sine egne oplysninger. Der er ingen synkronisering mellem iPads. Del en JSON-backup, og importer den på en anden iPad, når oplysninger skal flyttes. Sletning af appen kan også slette dens lokale backupmappe. Kopier en backup til iCloud Drive eller en anden placering, hvis den skal bevares uafhængigt af appen.

Kontrakter åbnes med iPadens forhåndsvisning og deles gennem Mail/Beskeder/Filer. Kalenderudskrivning bruger iPadens udskriftsmenu. Appen sender ikke automatisk e-mail eller SMS.

## Installation på flere iPads med TestFlight

En usigneret `.ipa` kan ikke installeres direkte. Den dokumenterer device-buildet og leveres lokalt som QA-bevis; kilde-ZIP'en indeholder kilder, ikke en IPA. Distribution via TestFlight eller App Store kræver adgang til et betalt **Apple Developer Program-team** og dets **App Store Connect**. Intet team eller certifikat er ændret i projektet.

1. Åbn `native/Hjortemosen.xcodeproj` i Xcode på en Mac. Vælg target **Hjortemosen → Signing & Capabilities**, og vælg det autoriserede Apple Developer-team. Bevar bundle-ID `dk.hjortemosen.booking`, medmindre teamet allerede har reserveret et andet ID til appen. Et ændret bundle-ID bliver en særskilt app og overtager ikke automatisk gamle lokale data.
2. Opret den tilsvarende app i App Store Connect med samme bundle-ID. Vælg en generisk iOS-enhed i Xcode, og brug **Product → Archive**.
3. Vælg arkivet i **Organizer → Distribute App → App Store Connect**. Kontrollér og upload det signerede build. Lad Xcode bruge teamets godkendte signering; accepter ikke aftaler eller opret certifikater uden teamets autorisation.
4. Når buildet er behandlet, tilføjes det til en TestFlight-gruppe. Inviter de ønskede testere, som installerer **TestFlight** på deres iPad og accepterer invitationen. Ekstern test og App Store-udgivelse kan kræve Apples review.

Det samme arkiv kan senere bruges til App Store-review, når beskrivelse, privatlivsoplysninger, supportadresse og screenshots er udfyldt. Appen kræver iPadOS 16 eller nyere. Apples review afgør, om den kan distribueres; en lokal buildkontrol er ikke en godkendelse.

[Apples distributionsvejledning](https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases/), [TestFlight](https://developer.apple.com/help/app-store-connect/test-a-beta-version/testflight-overview/).

## Byg og test

Fra repository-roden:

```sh
sh native/scripts/test-store.sh
sh native/scripts/build.sh simulator
sh native/scripts/build.sh device
```

Simulator-app: `native/.build/simulator/Build/Products/Debug-iphonesimulator/Hjortemosen.app`.
Device-app: `native/.build/device/Build/Products/Release-iphoneos/Hjortemosen.app`.
Usigneret pakke: `native/.build/device/Hjortemosen-unsigned.ipa`.

Et signeret arkiv kan bygges efter teamopsætningen:

```sh
HJORT_TEAM_ID=TEAM_ID sh native/scripts/build.sh archive
```

`ExportOptions.example.plist` er en skabelon til eksport til App Store Connect. Udfyld team-ID i en lokal kopi, og brug `xcodebuild -exportArchive` eller Xcodes Organizer. Buildscriptet logger ikke Apple-login og bruger ikke automatisk provisioning-opdatering.

Webfilerne kopieres fra repository-roden ved hver build efter `WebAssets.json`. Git-data, tests, lokale kundeoplysninger og andre filer kommer ikke med. Appikonet er samme husfoto som webappen, skaleret til Apples 1024 × 1024-format. Ved ændring af rodens ikon opdateres `native/Assets.xcassets/AppIcon.appiconset/AppIcon.png` tilsvarende.

## Native bridge

Kun hovedrammen fra `http://127.0.0.1:8716` kan kalde `window.webkit.messageHandlers.hjortemosen.postMessage(...)`. Alle anmodninger har `version: 1` og en `action`:

| Action | Felter | Svar |
| --- | --- | --- |
| `backup` | `snapshot`: fuld JSON-streng | `ok`, `savedAt`, `file` efter varig filskrivning |
| `readLatest` | — | `ok`, `snapshot`: JSON-streng eller `null` |
| `openBackups` | — | `ok`, `cancelled` eller `selected`; åbner dokumentvælger, importerer ikke |
| `share` | `name`, `mimeType`, `base64` | `ok`, `cancelled`; bruger systemets delingsmenu |
| `preview` | samme filfelter | `ok` efter lukket Quick Look |
| `printCalendar` | `html`: escaped kalender med inline CSS | `ok`, `cancelled` efter lukket udskriftsmenu |

Fejl returnerer `ok: false` og en dansk `error`. Filer højst 20 MiB, snapshots højst 10 MiB; filnavne må ikke indeholde stier. HTML til kalenderudskrift må ikke indlæse eksterne ressourcer. Den lokale HTTP-listener binder kun loopback og serverer kendte, indbyggede assets. Den har ingen HTTP-endpoints til data eller native handlinger. Hvis den faste port er optaget, åbnes ingen fremmed server, og appen viser en fejl.

WKWebView bruger det offentlige standardlager og samme origin ved genåbning. Ingen private WebKit-indstillinger anvendes. Før baggrundssuspension venter UIKit på `saveOpenForms()` og `HjortNative.flush()` samt native skrivekøen inden for iPadOS' tilladte baggrundstid.

Appen bruger én offentlig `UIWindowScene` og en `SceneDelegate`. Både tab af fokus og overgang til baggrund starter gemning. Samtidige gemninger tælles, så en tidligere callback ikke afslutter baggrundstiden for en senere gemning.

Den faktiske WKWebView-prøve findes i `native/XCUITests/NativeFlowTests.swift` og kan køres med projektets delte **Hjortemosen**-scheme på en dedikeret iPad-simulator. Prøven skriver en særskilt QA-kladdetekst, kontrollerer en automatisk backupkvittering, genåbner appen og afprøver begge knapper i den native bekræftelsesdialog. Den seneste JSON-fil i simulatorens Documents skal også inspiceres for den afsluttende kladdetekst; en skærmkvittering alene dokumenterer ikke filens indhold.

For 2.6.1/build 261 består begge Xcode SDK 27-builds og de 18 Swift-filprøver. Begge appbundles matcher alle 21 frosne webassets. Native UI-prøven blev blokeret i simulatorens testmanager før app-testen, også efter én genstart med data bevaret. Der blev kørt nul app-tests, og den dedikerede QA-simulator havde ingen matchende Hjortemosen-datacontainer ved filinspektion. Native kladdegenåbning, faktisk backupkvittering, UIKit-bekræftelse og den afsluttende JSON er derfor endnu ikke verificeret i simulator eller på en fysisk iPad. Usigneret build er heller ikke en TestFlight- eller App Store-udgivelse.
