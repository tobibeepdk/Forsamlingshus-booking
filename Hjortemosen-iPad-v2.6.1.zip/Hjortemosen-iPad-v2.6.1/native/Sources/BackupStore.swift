import Foundation
import CoreFoundation
import Darwin

enum NativeBackupError: LocalizedError {
    case invalid, missingPrimary, tooLarge, storage
    var errorDescription: String? {
        switch self {
        case .invalid: return "Sikkerhedskopien har et ugyldigt eller ufuldstændigt format. Den sidste gyldige kopi er bevaret."
        case .missingPrimary: return "Appens gemte data mangler. Den sidste backup er bevaret og kan gendannes."
        case .tooLarge: return "Sikkerhedskopien er for stor. Den sidste gyldige kopi er bevaret."
        case .storage: return "Backup kunne ikke skrives til iPadens lager. Frigør plads og prøv igen."
        }
    }
}

struct ValidatedSnapshot {
    let object: [String: Any]
    let dataPresent: Bool
    let payload: Data
    static func bool(_ value: Any?) -> Bool? {
        guard let value = value as? NSNumber, CFGetTypeID(value) == CFBooleanGetTypeID() else { return nil }
        return value.boolValue
    }
    static func amount(_ value: Any?) -> Double? {
        if let string = value as? String, !string.isEmpty, let number = Double(string), number.isFinite, number >= 0 { return number }
        if let number = value as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID(), number.doubleValue.isFinite, number.doubleValue >= 0 { return number.doubleValue }
        return nil
    }
    static func text(_ value: Any?, max: Int = 20000) -> Bool { (value as? String).map { $0.utf16.count <= max } ?? false }
    static func date(_ value: Any?) -> Bool {
        guard let value = value as? String, value.count == 10,
              value.range(of: "^[0-9]{4}-[0-9]{2}-[0-9]{2}$", options: .regularExpression) != nil else { return false }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.isLenient = false
        return formatter.date(from: value).map { formatter.string(from: $0) == value } ?? false
    }
    static func validBooking(_ record: [String: Any]) -> Bool {
        guard date(record["date"]), let type = record["type"] as? String,
              ["member", "friend", "board", "other"].contains(type), let price = amount(record["price"]) else { return false }
        if let deposit = record["deposit"], amount(deposit) == nil { return false }
        if type == "board" && (price != 0 || ![0.0, 500.0].contains(amount(record["deposit"]) ?? 0)) { return false }
        return ["paid", "depositPaid"].allSatisfy { record[$0] == nil || bool(record[$0]) != nil }
    }
    static func draft(_ kind: String, _ value: Any?) -> Bool {
        guard let value else { return false }
        if value is NSNull { return true }
        guard let draft = value as? [String: Any] else { return false }
        if kind == "contract" {
            guard let template = draft["template"] as? String, ["member-pdf", "friend-pdf", "member-word"].contains(template),
                  text(draft["bookingId"], max: 200), text(draft["bookingSnapshot"]), let fields = draft["values"] as? [String: Any],
                  let strokes = draft["strokes"] as? [[[Any]]], strokes.count <= 1000 else { return false }
            let limits = ["name":200, "phone":60, "email":254, "address":300, "account":100, "agreementDate":10, "rentalDate":10, "meterStart":40, "meterEnd":40, "signature":200]
            guard limits.allSatisfy({ text(fields[$0.key], max: $0.value) }),
                  ["agreementDate", "rentalDate"].allSatisfy({ (fields[$0] as? String) == "" || date(fields[$0]) }) else { return false }
            if let raw = draft["bookingSnapshot"] as? String, !raw.isEmpty {
                guard let rawData = raw.data(using: .utf8), let booking = (try? JSONSerialization.jsonObject(with: rawData)) as? [String: Any],
                      date(booking["date"]), ["member", "friend", "board", "other"].contains(booking["type"] as? String ?? ""), amount(booking["price"]) != nil,
                      ["name", "phone", "address", "email"].allSatisfy({ booking[$0] == nil || text(booking[$0]) }) else { return false }
            }
            var count = 0
            for stroke in strokes {
                count += stroke.count
                guard !stroke.isEmpty, count <= 30000 else { return false }
                for point in stroke {
                    guard point.count == 2, let x = amount(point[0]), let y = amount(point[1]), x <= 1200, y <= 400 else { return false }
                }
            }
            return true
        }
        let fields = kind == "booking" ? ["id", "date", "name", "houseNo", "phone", "email", "address", "notes"] : kind == "settings" ? ["memberPrice", "friendPrice", "deposit", "baseSettings"] : ["name", "house", "reason"]
        guard fields.allSatisfy({ draft[$0] == nil || text(draft[$0]) }) else { return false }
        if kind == "booking" {
            if let baseline = draft["baseBooking"], !(baseline is NSNull), !text(baseline) { return false }
            if let type = draft["type"], !["member", "friend", "board", "other"].contains(type as? String ?? "") { return false }
            if let value = draft["date"] as? String, !value.isEmpty, !date(value) { return false }
            for key in ["price", "deposit"] {
                if let value = draft[key], !(value is String), !(value is NSNumber && bool(value) == nil) { return false }
            }
            guard ["paid", "depositPaid", "saveRenter"].allSatisfy({ draft[$0] == nil || bool(draft[$0]) != nil }) else { return false }
        }
        return true
    }
    init(_ raw: String) throws {
        guard let data = raw.data(using: .utf8), data.count <= 10 * 1024 * 1024 else { throw NativeBackupError.tooLarge }
        guard var object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              var metadata = object["backup"] as? [String: Any], metadata["format"] as? String == "hjortemosen-backup",
              (metadata["version"] as? NSNumber)?.doubleValue == 1, Self.bool(metadata["version"]) == nil,
              let dataPresent = Self.bool(metadata["dataPresent"]), Self.text(metadata["appVersion"], max: 100),
              let savedAt = metadata["savedAt"] as? String, Self.timestamp(savedAt), let drafts = metadata["drafts"] as? [String: Any],
              ["booking", "contract", "settings", "blacklist"].allSatisfy({ Self.draft($0, drafts[$0]) }),
              let settings = object["settings"] as? [String: Any],
              ["memberPrice", "friendPrice", "otherPrice", "deposit"].allSatisfy({ Self.amount(settings[$0]) != nil }) else { throw NativeBackupError.invalid }
        for key in ["bookings", "renters", "blacklist"] {
            guard let records = object[key] as? [[String: Any]], records.count <= 10000 else { throw NativeBackupError.invalid }
            var ids = Set<String>(), dates = Set<String>()
            for record in records {
                guard let id = record["id"] as? String, !id.isEmpty, ids.insert(id).inserted,
                      let name = record["name"] as? String, !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                      ["houseNo", "house", "phone", "email", "address", "notes", "reason"].allSatisfy({ record[$0] == nil || Self.text(record[$0]) }) else { throw NativeBackupError.invalid }
                if key == "bookings" {
                    guard Self.validBooking(record), let date = record["date"] as? String, dates.insert(date).inserted else { throw NativeBackupError.invalid }
                }
            }
        }
        self.object = object
        self.dataPresent = dataPresent
        metadata["savedAt"] = ""
        object["backup"] = metadata
        payload = try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
    }
    private static func timestamp(_ value: String) -> Bool {
        guard value.utf16.count <= 100 else { return false }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if formatter.date(from: value) != nil { return true }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: value) != nil
    }
}

struct NativeBackupReceipt {
    let savedAt: String
    let file: String
}

final class NativeBackupStore {
    let directory: URL
    private let lock = NSLock()
    var latestURL: URL { directory.appendingPathComponent("seneste-backup.json") }
    init(documents: URL) throws {
        directory = documents.appendingPathComponent("Hjortemosen", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }
    func save(snapshot: String) throws -> NativeBackupReceipt {
        lock.lock(); defer { lock.unlock() }
        let incoming = try ValidatedSnapshot(snapshot)
        let oldData = try existingData()
        if let oldData {
            guard let raw = String(data: oldData, encoding: .utf8) else { throw NativeBackupError.invalid }
            let previous = try ValidatedSnapshot(raw)
            if previous.dataPresent && !incoming.dataPresent { throw NativeBackupError.missingPrimary }
            if previous.payload != incoming.payload {
                let archive = directory.appendingPathComponent("backup-\(Self.timestamp())-\(UUID().uuidString).json")
                try atomicWrite(oldData, to: archive)
            }
        }
        guard let data = snapshot.data(using: .utf8) else { throw NativeBackupError.invalid }
        try atomicWrite(data, to: latestURL)
        try prune()
        return NativeBackupReceipt(savedAt: ISO8601DateFormatter().string(from: Date()), file: "Hjortemosen/seneste-backup.json")
    }
    func readLatest() throws -> String? {
        lock.lock(); defer { lock.unlock() }
        guard let data = try existingData() else { return nil }
        guard let raw = String(data: data, encoding: .utf8) else { throw NativeBackupError.invalid }
        _ = try ValidatedSnapshot(raw)
        return raw
    }
    private func existingData() throws -> Data? {
        guard FileManager.default.fileExists(atPath: latestURL.path) else { return nil }
        let attributes = try FileManager.default.attributesOfItem(atPath: latestURL.path)
        guard attributes[.type] as? FileAttributeType == .typeRegular else { throw NativeBackupError.storage }
        guard let size = attributes[.size] as? NSNumber, size.intValue <= 10 * 1024 * 1024 else { throw NativeBackupError.tooLarge }
        return try Data(contentsOf: latestURL)
    }
    private static func timestamp() -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyyMMdd'T'HHmmssSSS"
        return formatter.string(from: Date())
    }
    private func prune() throws {
        let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.creationDateKey])
            .filter { $0.lastPathComponent.hasPrefix("backup-") && $0.pathExtension == "json" }
            .sorted { $0.lastPathComponent < $1.lastPathComponent }
        for file in files.prefix(max(0, files.count - 10)) { try FileManager.default.removeItem(at: file) }
    }
    private func atomicWrite(_ data: Data, to target: URL) throws {
        let pending = directory.appendingPathComponent(".pending-\(UUID().uuidString)")
        let fd = open(pending.path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, mode_t(S_IRUSR | S_IWUSR))
        guard fd >= 0 else { throw NativeBackupError.storage }
        var closed = false
        defer { if !closed { close(fd) }; try? FileManager.default.removeItem(at: pending) }
        try data.withUnsafeBytes { bytes in
            guard let base = bytes.baseAddress else { throw NativeBackupError.invalid }
            var written = 0
            while written < bytes.count {
                let result = Darwin.write(fd, base.advanced(by: written), bytes.count - written)
                if result < 0 && errno == EINTR { continue }
                guard result > 0 else { throw NativeBackupError.storage }
                written += result
            }
        }
        guard fsync(fd) == 0 else { throw NativeBackupError.storage }
        guard close(fd) == 0 else { closed = true; throw NativeBackupError.storage }
        closed = true
        #if os(iOS)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: pending.path)
        #endif
        guard rename(pending.path, target.path) == 0 else { throw NativeBackupError.storage }
        let dirFD = open(directory.path, O_RDONLY | O_CLOEXEC)
        guard dirFD >= 0 else { throw NativeBackupError.storage }
        defer { close(dirFD) }
        guard fsync(dirFD) == 0 else { throw NativeBackupError.storage }
    }
}
