import Foundation
import Network

enum LocalWebServerError: LocalizedError {
    case unavailable, assetsMissing
    var errorDescription: String? {
        switch self {
        case .unavailable: return "Appens lokale forbindelse kunne ikke startes. Luk andre Hjortemosen-vinduer og åbn appen igen."
        case .assetsMissing: return "Appens indbyggede filer mangler. Installer appen igen uden at slette den gamle apps data."
        }
    }
}

/// Serves only shipped, public assets. No data or native commands cross HTTP.
final class LocalWebServer {
    static let port: UInt16 = 8716
    static let origin = "http://127.0.0.1:\(port)"
    private let queue = DispatchQueue(label: "dk.hjortemosen.assets")
    private var listener: NWListener?
    private var connections: [ObjectIdentifier: NWConnection] = [:]
    private let assets: URL
    private let allowed: Set<String>
    init(bundle: Bundle = .main) throws {
        guard let assets = bundle.url(forResource: "Web", withExtension: nil),
              let listURL = bundle.url(forResource: "WebAssets", withExtension: "json"),
              let list = try? JSONDecoder().decode([String].self, from: Data(contentsOf: listURL)),
              FileManager.default.fileExists(atPath: assets.appendingPathComponent("index.html").path) else { throw LocalWebServerError.assetsMissing }
        self.assets = assets
        allowed = Set(list)
    }
    func start(completion: @escaping (Result<Void, Error>) -> Void) throws {
        let parameters = NWParameters.tcp
        parameters.requiredLocalEndpoint = .hostPort(host: .ipv4(.loopback), port: NWEndpoint.Port(rawValue: Self.port)!)
        parameters.allowLocalEndpointReuse = false
        let listener = try NWListener(using: parameters)
        self.listener = listener
        var completed = false
        listener.stateUpdateHandler = { state in
            switch state {
            case .ready:
                if !completed { completed = true; DispatchQueue.main.async { completion(.success(())) } }
            case .failed:
                if !completed { completed = true; DispatchQueue.main.async { completion(.failure(LocalWebServerError.unavailable)) } }
                listener.cancel()
            default: break
            }
        }
        listener.newConnectionHandler = { [weak self] connection in
            guard let self else { connection.cancel(); return }
            let id = ObjectIdentifier(connection)
            self.connections[id] = connection
            connection.stateUpdateHandler = { [weak self] state in
                if case .cancelled = state { self?.connections.removeValue(forKey: id) }
                if case .failed = state { self?.connections.removeValue(forKey: id) }
            }
            connection.start(queue: self.queue)
            self.receive(connection, buffer: Data())
            self.queue.asyncAfter(deadline: .now() + 8) { connection.cancel() }
        }
        listener.start(queue: queue)
    }
    private func receive(_ connection: NWConnection, buffer: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { [weak self] data, _, ended, error in
            guard let self, error == nil else { connection.cancel(); return }
            var buffer = buffer
            if let data { buffer.append(data) }
            guard buffer.count <= 8192 else { self.respond(connection, code: 431, reason: "Request Header Fields Too Large", body: Data()); return }
            if let end = buffer.range(of: Data("\r\n\r\n".utf8)) {
                self.request(connection, header: String(decoding: buffer[..<end.lowerBound], as: UTF8.self))
            } else if ended { connection.cancel() } else { self.receive(connection, buffer: buffer) }
        }
    }
    private func request(_ connection: NWConnection, header: String) {
        let lines = header.components(separatedBy: "\r\n")
        let parts = (lines.first ?? "").split(separator: " ")
        guard parts.count == 3, ["GET", "HEAD"].contains(String(parts[0])), parts[2] == "HTTP/1.1" else {
            respond(connection, code: 405, reason: "Method Not Allowed", body: Data()); return
        }
        let host = lines.dropFirst().first { $0.lowercased().hasPrefix("host:") }?.dropFirst(5).trimmingCharacters(in: .whitespaces)
        guard host == "127.0.0.1:\(Self.port)" else { respond(connection, code: 400, reason: "Bad Request", body: Data()); return }
        let target = String(parts[1]).split(separator: "?", maxSplits: 1, omittingEmptySubsequences: false)[0]
        guard let path = String(target).removingPercentEncoding, path.hasPrefix("/"), !path.contains("\\"), !path.contains("\0") else { respond(connection, code: 400, reason: "Bad Request", body: Data()); return }
        let file = path == "/" ? "index.html" : String(path.dropFirst())
        guard allowed.contains(file), let data = try? Data(contentsOf: assets.appendingPathComponent(file)) else { respond(connection, code: 404, reason: "Not Found", body: Data()); return }
        let mime: [String: String] = ["html":"text/html; charset=utf-8", "css":"text/css; charset=utf-8", "js":"text/javascript; charset=utf-8", "json":"application/json", "webmanifest":"application/manifest+json", "svg":"image/svg+xml", "png":"image/png", "jpg":"image/jpeg", "pdf":"application/pdf", "docx":"application/vnd.openxmlformats-officedocument.wordprocessingml.document", "txt":"text/plain; charset=utf-8"]
        respond(connection, code: 200, reason: "OK", body: data, mime: mime[URL(fileURLWithPath: file).pathExtension] ?? "application/octet-stream", head: parts[0] == "HEAD")
    }
    private func respond(_ connection: NWConnection, code: Int, reason: String, body: Data, mime: String = "text/plain", head: Bool = false) {
        let csp = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'none'"
        let header = "HTTP/1.1 \(code) \(reason)\r\nContent-Type: \(mime)\r\nContent-Length: \(body.count)\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nContent-Security-Policy: \(csp)\r\nReferrer-Policy: no-referrer\r\n\r\n"
        var output = Data(header.utf8)
        if !head { output.append(body) }
        connection.send(content: output, completion: .contentProcessed { _ in connection.cancel() })
    }
    deinit { listener?.cancel(); connections.values.forEach { $0.cancel() } }
}
