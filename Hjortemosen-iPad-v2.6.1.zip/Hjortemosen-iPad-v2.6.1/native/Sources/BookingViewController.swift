import UIKit
import WebKit
import UniformTypeIdentifiers
import QuickLook

final class BookingViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandlerWithReply, UIDocumentPickerDelegate, QLPreviewControllerDataSource, QLPreviewControllerDelegate {
    private var webView: WKWebView!
    private var server: LocalWebServer?
    private var store: NativeBackupStore?
    private let storeQueue = DispatchQueue(label: "dk.hjortemosen.backup", qos: .userInitiated)
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    private var pendingFlushes = 0
    private var pickerReply: ((Any?, String?) -> Void)?
    private var previewURL: URL?
    private var previewFolder: URL?
    private var previewReply: ((Any?, String?) -> Void)?
    private var activeShareURL: URL?
    private let loading = UILabel()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.93, alpha: 1)
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        configuration.userContentController.addScriptMessageHandler(self, contentWorld: .page, name: "hjortemosen")
        let bootstrap = "Object.defineProperty(window,'__HJORT_NATIVE__',{value:true,writable:false});"
        configuration.userContentController.addUserScript(WKUserScript(source: bootstrap, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        view.addSubview(webView)
        NSLayoutConstraint.activate([webView.leadingAnchor.constraint(equalTo: view.leadingAnchor), webView.trailingAnchor.constraint(equalTo: view.trailingAnchor), webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor), webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)])
        loading.text = "Åbner Hjortemosen…"
        loading.numberOfLines = 0
        loading.textAlignment = .center
        loading.font = .preferredFont(forTextStyle: .body)
        loading.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(loading)
        NSLayoutConstraint.activate([loading.centerXAnchor.constraint(equalTo: view.centerXAnchor), loading.centerYAnchor.constraint(equalTo: view.centerYAnchor), loading.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.85)])
        do {
            let documents = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            store = try NativeBackupStore(documents: documents)
            let server = try LocalWebServer()
            self.server = server
            try server.start { [weak self] result in
                switch result {
                case .success: self?.webView.load(URLRequest(url: URL(string: LocalWebServer.origin + "/")!))
                case .failure(let error): self?.showStartError(error)
                }
            }
        } catch { showStartError(error) }
    }
    private func showStartError(_ error: Error) {
        loading.isHidden = false
        loading.text = error.localizedDescription + "\n\nDine tidligere gemte data er bevaret."
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { loading.isHidden = true }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { showStartError(error) }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        loading.isHidden = false
        loading.text = "Genåbner dine gemte oplysninger…"
        webView.load(URLRequest(url: URL(string: LocalWebServer.origin + "/")!))
    }
    private func owns(_ frame: WKFrameInfo) -> Bool {
        let origin = frame.securityOrigin
        return frame.isMainFrame && origin.protocol == "http" && origin.host == "127.0.0.1" && origin.port == Int(LocalWebServer.port)
    }
    private func ownURL(_ url: URL) -> Bool { url.scheme == "http" && url.host == "127.0.0.1" && url.port == Int(LocalWebServer.port) }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage, replyHandler: @escaping (Any?, String?) -> Void) {
        guard message.name == "hjortemosen", owns(message.frameInfo), message.webView === webView,
              let body = message.body as? [String: Any], let version = body["version"] as? NSNumber,
              ValidatedSnapshot.bool(version) == nil, version.doubleValue == 1, let action = body["action"] as? String else {
            replyHandler(["ok":false, "error":"Anmodningen kommer ikke fra Hjortemosen-appen."], nil); return
        }
        switch action {
        case "backup":
            guard let snapshot = body["snapshot"] as? String, let store else { replyHandler(["ok":false, "error":"Sikkerhedskopien mangler."], nil); return }
            storeQueue.async {
                let response: [String: Any]
                do { let receipt = try store.save(snapshot: snapshot); response = ["ok":true, "savedAt":receipt.savedAt, "file":receipt.file] }
                catch { response = ["ok":false, "error":error.localizedDescription] }
                DispatchQueue.main.async { replyHandler(response, nil) }
            }
        case "readLatest":
            guard let store else { replyHandler(["ok":false, "error":"Backupmappen kunne ikke åbnes."], nil); return }
            storeQueue.async {
                let response: [String: Any]
                do { response = ["ok":true, "snapshot":try store.readLatest() as Any? ?? NSNull()] }
                catch { response = ["ok":false, "error":error.localizedDescription] }
                DispatchQueue.main.async { replyHandler(response, nil) }
            }
        case "openBackups": openBackups(replyHandler)
        case "share": share(body, replyHandler)
        case "preview": preview(body, replyHandler)
        case "printCalendar": printCalendar(body, replyHandler)
        default: replyHandler(["ok":false, "error":"Denne handling understøttes ikke."], nil)
        }
    }
    private func canPresent(_ reply: @escaping (Any?, String?) -> Void) -> Bool {
        guard presentedViewController == nil else { reply(["ok":false, "error":"Luk den åbne menu, og prøv igen."], nil); return false }
        return true
    }
    private func openBackups(_ reply: @escaping (Any?, String?) -> Void) {
        guard canPresent(reply), let store else { return }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.json], asCopy: false)
        picker.directoryURL = store.directory
        picker.allowsMultipleSelection = false
        picker.delegate = self
        pickerReply = reply
        present(picker, animated: true)
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        pickerReply?(["ok":true, "cancelled":true], nil); pickerReply = nil
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        // Browsing does not silently import another document into the workspace.
        pickerReply?(["ok":true, "selected":true], nil); pickerReply = nil
    }
    private func share(_ body: [String: Any], _ reply: @escaping (Any?, String?) -> Void) {
        guard canPresent(reply) else { return }
        do {
            let url = try prepareFile(body)
            let folder = url.deletingLastPathComponent()
            activeShareURL = url
            let activity = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            activity.popoverPresentationController?.sourceView = webView
            activity.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
            activity.completionWithItemsHandler = { [weak self] _, completed, _, error in
                if let error { reply(["ok":false, "error":error.localizedDescription], nil) }
                else { reply(["ok":true, "cancelled":!completed], nil) }
                self?.activeShareURL = nil
                try? FileManager.default.removeItem(at: folder)
            }
            present(activity, animated: true)
        } catch { reply(["ok":false, "error":error.localizedDescription], nil) }
    }
    private func prepareFile(_ body: [String: Any]) throws -> URL {
        guard let name = body["name"] as? String, !name.isEmpty, name.utf16.count <= 180,
              !name.contains("/"), !name.contains("\\"), name != ".", name != "..", !name.contains("\0"),
              name.rangeOfCharacter(from: .controlCharacters) == nil,
              let mime = body["mimeType"] as? String,
              ["application/pdf", "application/json", "text/plain", "text/plain;charset=utf-8", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"].contains(mime),
              let base64 = body["base64"] as? String, base64.utf8.count <= 28 * 1024 * 1024,
              let data = Data(base64Encoded: base64), !data.isEmpty, data.count <= 20 * 1024 * 1024 else {
            throw NSError(domain: "Hjortemosen", code: 2, userInfo: [NSLocalizedDescriptionKey:"Filen har et ugyldigt navn, format eller størrelse."])
        }
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("hjort-share-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let url = folder.appendingPathComponent(name)
        do { try data.write(to: url, options: [.atomic]); return url }
        catch { try? FileManager.default.removeItem(at: folder); throw NativeBackupError.storage }
    }
    private func preview(_ body: [String: Any], _ reply: @escaping (Any?, String?) -> Void) {
        guard canPresent(reply) else { return }
        do {
            previewURL = try prepareFile(body)
            previewFolder = previewURL?.deletingLastPathComponent()
            previewReply = reply
            let controller = QLPreviewController()
            controller.dataSource = self
            controller.delegate = self
            present(controller, animated: true)
        } catch { reply(["ok":false, "error":error.localizedDescription], nil) }
    }
    private func printCalendar(_ body: [String: Any], _ reply: @escaping (Any?, String?) -> Void) {
        guard canPresent(reply) else { return }
        guard let html = body["html"] as? String, html.utf8.count <= 2 * 1024 * 1024,
              html.range(of: "<(script|iframe|object|embed|form|link|img|video|audio)\\b|(?:src|href)\\s*=|url\\s*\\(", options: [.regularExpression, .caseInsensitive]) == nil else {
            reply(["ok":false, "error":"Kalenderen kunne ikke klargøres til udskrivning."], nil); return
        }
        let printController = UIPrintInteractionController.shared
        let info = UIPrintInfo(dictionary: nil)
        info.jobName = "Hjortemosen bookingkalender"
        info.outputType = .general
        info.orientation = .landscape
        printController.printInfo = info
        printController.printFormatter = UIMarkupTextPrintFormatter(markupText: html)
        printController.present(from: CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1), in: webView, animated: true) { _, completed, error in
            if let error { reply(["ok":false, "error":error.localizedDescription], nil) }
            else { reply(["ok":true, "cancelled":!completed], nil) }
        }
    }
    func flushBeforeSuspending() {
        guard isViewLoaded, webView != nil else { return }
        pendingFlushes += 1
        if backgroundTask == .invalid {
            backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "Gem Hjortemosen backup") { [weak self] in self?.finishBackgroundTask() }
        }
        let script = "await window.saveOpenForms?.(); await window.HjortNative?.flush?.();"
        webView.callAsyncJavaScript(script, arguments: [:], in: nil, in: .page) { [weak self] _ in
            guard let self else { return }
            self.storeQueue.async {
                DispatchQueue.main.async {
                    self.pendingFlushes -= 1
                    if self.pendingFlushes == 0 { self.finishBackgroundTask() }
                }
            }
        }
    }
    private func finishBackgroundTask() {
        guard backgroundTask != .invalid else { return }
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = .invalid
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if ownURL(url) {
            if ["pdf", "docx"].contains(url.pathExtension), navigationAction.navigationType == .linkActivated {
                decisionHandler(.cancel); previewAsset(url); return
            }
            decisionHandler(.allow); return
        }
        if url.scheme == "blob", owns(navigationAction.sourceFrame) { decisionHandler(.allow); return }
        if navigationAction.navigationType == .linkActivated, ["mailto", "sms", "tel", "https"].contains(url.scheme ?? "") {
            UIApplication.shared.open(url)
        }
        decisionHandler(.cancel)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url, ownURL(url), ["pdf", "docx"].contains(url.pathExtension) { previewAsset(url) }
        return nil
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard owns(frame), presentedViewController == nil else { completionHandler(false); return }
        let alert = UIAlertController(title: "Hjortemosen", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Annuller", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "Ja, fortsæt", style: .default) { _ in completionHandler(true) })
        present(alert, animated: true)
    }
    private func previewAsset(_ url: URL) {
        guard presentedViewController == nil, let asset = Bundle.main.url(forResource: "Web", withExtension: nil)?.appendingPathComponent(url.lastPathComponent),
              ["kontrakt-1000.pdf", "kontrakt-1500.pdf", "kontrakt-1000.docx"].contains(url.lastPathComponent) else { return }
        previewURL = asset
        let controller = QLPreviewController()
        controller.dataSource = self
        controller.delegate = self
        present(controller, animated: true)
    }
    func numberOfPreviewItems(in controller: QLPreviewController) -> Int { previewURL == nil ? 0 : 1 }
    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem { previewURL! as NSURL }
    func previewControllerDidDismiss(_ controller: QLPreviewController) {
        previewReply?(["ok":true, "cancelled":false], nil)
        previewReply = nil
        previewURL = nil
        if let previewFolder { try? FileManager.default.removeItem(at: previewFolder) }
        previewFolder = nil
    }
}
