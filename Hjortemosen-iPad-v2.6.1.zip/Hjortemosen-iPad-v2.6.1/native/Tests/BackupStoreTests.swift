import Foundation

@main
struct BackupStoreTests {
    static func snapshot(_ number: Int = 0, dataPresent: Bool = true) throws -> String {
        let values = ["name":"QA", "phone":"", "email":"", "address":"", "account":"", "agreementDate":"2026-10-03", "rentalDate":"2026-12-22", "meterStart":"", "meterEnd":"", "signature":"QA"]
        let value: [String: Any] = ["bookings": number == 0 ? [] : [["id":"qa", "name":"QA \(number)", "date":"2026-12-22", "type":"board", "price":0, "deposit":500, "paid":false, "depositPaid":false]], "renters":[], "blacklist":[], "settings":["memberPrice":1000, "friendPrice":1500, "otherPrice":1500, "deposit":500], "backup":["format":"hjortemosen-backup", "version":1, "appVersion":"2.6.0", "dataPresent":dataPresent, "savedAt":"2026-10-03T12:00:00.000Z", "drafts":["booking":NSNull(), "contract":["template":"member-pdf", "bookingId":"", "bookingSnapshot":"", "values":values, "strokes":[[[20,20],[50,40]]]], "settings":NSNull(), "blacklist":NSNull()]]]
        return String(data: try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]), encoding: .utf8)!
    }
    static func run() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("hjort-native-tests-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: root) }
        let store = try NativeBackupStore(documents: root)
        func require(_ result: @autoclosure () throws -> Bool, _ label: String) throws {
            guard try result() else { throw NSError(domain: "Test", code: 1, userInfo: [NSLocalizedDescriptionKey: "FAIL: \(label)"]) }
            print("PASS: \(label)")
        }
        try require(store.readLatest() == nil, "empty store has no file")
        let first = try snapshot(1)
        let receipt = try store.save(snapshot: first)
        try require(try store.readLatest() == first, "real latest file contains full snapshot and ink")
        try require(receipt.file == "Hjortemosen/seneste-backup.json", "receipt is Files-relative")
        try require(ISO8601DateFormatter().date(from: receipt.savedAt) != nil, "receipt gives a valid durable-write timestamp")
        do { _ = try store.save(snapshot: "{broken"); throw NSError(domain: "Test", code: 1) } catch {
            try require(try store.readLatest() == first, "bad JSON preserves last good file")
        }
        do { _ = try store.save(snapshot: "{\"backup\":{\"format\":\"hjortemosen-backup\",\"version\":1}}"); throw NSError(domain:"Test",code:1) } catch {
            try require(try store.readLatest() == first, "incomplete snapshot preserves last good file")
        }
        do { _ = try store.save(snapshot: try snapshot(0, dataPresent: false)); throw NSError(domain:"Test",code:1) } catch {
            try require(try store.readLatest() == first, "missing primary data cannot erase populated backup")
        }
        for number in 2...16 { _ = try store.save(snapshot: try snapshot(number)) }
        let files = try FileManager.default.contentsOfDirectory(at: store.directory, includingPropertiesForKeys: nil)
        let history = files.filter { $0.lastPathComponent.hasPrefix("backup-") }
        try require(history.count == 10, "only ten previous versions retained")
        try require(try store.readLatest() == snapshot(16), "latest remains newest after pruning")
        for file in history {
            _ = try JSONSerialization.jsonObject(with: Data(contentsOf: file))
        }
        try require(!files.contains { $0.lastPathComponent.hasPrefix(".pending-") }, "no temporary files remain")
        let reopened = try NativeBackupStore(documents: root)
        try require(try reopened.readLatest() == snapshot(16), "fresh store reopens durable content")
        _ = try reopened.save(snapshot: try snapshot(16))
        try require(try FileManager.default.contentsOfDirectory(at: store.directory, includingPropertiesForKeys: nil).filter { $0.lastPathComponent.hasPrefix("backup-") }.count == 10, "unchanged snapshot does not add another history version")
        let fresh = try NativeBackupStore(documents: root.appendingPathComponent("fresh"))
        _ = try fresh.save(snapshot: try snapshot(0, dataPresent: false))
        try require(try fresh.readLatest() != nil, "new app can back up unsigned draft-only workspace")
        let damaged = try NativeBackupStore(documents: root.appendingPathComponent("damaged"))
        let corrupt = Data([0xff, 0xfe, 0x80])
        try corrupt.write(to: damaged.latestURL)
        var rejectedRead = false
        do { _ = try damaged.readLatest() } catch { rejectedRead = true }
        try require(rejectedRead, "existing non-UTF8 backup reports error rather than absence")
        var rejectedWrite = false
        do { _ = try damaged.save(snapshot: try snapshot(0, dataPresent: false)) } catch { rejectedWrite = true }
        try require(rejectedWrite, "non-UTF8 previous file cannot be replaced by empty defaults")
        try require(try Data(contentsOf: damaged.latestURL) == corrupt, "damaged previous bytes remain available for recovery")
        let blocked = try NativeBackupStore(documents: root.appendingPathComponent("blocked"))
        _ = try blocked.save(snapshot: first)
        try FileManager.default.setAttributes([.posixPermissions:0o500], ofItemAtPath: blocked.directory.path)
        var rejectedStorage = false
        do { _ = try blocked.save(snapshot: try snapshot(2)) } catch { rejectedStorage = true }
        try FileManager.default.setAttributes([.posixPermissions:0o700], ofItemAtPath: blocked.directory.path)
        try require(rejectedStorage, "real filesystem write failure is reported")
        try require(try blocked.readLatest() == first, "filesystem write failure preserves last good file")
    }
    static func main() {
        do { try run(); print("Native backup tests complete.") } catch { fputs("\(error.localizedDescription)\n", stderr); exit(1) }
    }
}
