#!/usr/bin/env python3
"""Copy the explicit public web assets; never copy Git, drafts or test data."""
import json
import os
from pathlib import Path
import shutil

native = Path(__file__).resolve().parent.parent
root = native.parent
allowlist = json.loads((native / "WebAssets.json").read_text())
build_dir = Path(os.environ.get("DERIVED_FILE_DIR", native / ".build"))
resources = Path(os.environ["TARGET_BUILD_DIR"]) / os.environ["UNLOCALIZED_RESOURCES_FOLDER_PATH"] if "TARGET_BUILD_DIR" in os.environ else build_dir / "resources"
web = resources / "Web"
web.mkdir(parents=True, exist_ok=True)
for filename in allowlist:
    if Path(filename).name != filename or not (root / filename).is_file():
        raise SystemExit(f"Required web asset is missing or invalid: {filename}")
    shutil.copyfile(root / filename, web / filename)
shutil.copyfile(native / "WebAssets.json", resources / "WebAssets.json")
print(f"Prepared {len(allowlist)} bundled web assets.")
