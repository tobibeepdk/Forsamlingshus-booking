#!/bin/sh
set -eu
native_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
test_dir=$(mktemp -d "${TMPDIR:-/tmp}/hjort-native-tests.XXXXXX")
trap 'rm -rf "$test_dir"' EXIT HUP INT TERM
xcrun swiftc -module-cache-path "$test_dir/module-cache" "$native_dir/Sources/BackupStore.swift" "$native_dir/Tests/BackupStoreTests.swift" -o "$test_dir/backup-tests"
"$test_dir/backup-tests"
