#!/bin/sh
set -eu
native_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
mode=${1:-simulator}
case "$mode" in
  simulator)
    xcodebuild -project "$native_dir/Hjortemosen.xcodeproj" -scheme Hjortemosen -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath "$native_dir/.build/simulator" CODE_SIGNING_ALLOWED=NO build
    ;;
  device)
    xcodebuild -project "$native_dir/Hjortemosen.xcodeproj" -scheme Hjortemosen -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath "$native_dir/.build/device" CODE_SIGNING_ALLOWED=NO build
    package_dir="$native_dir/.build/device/unsigned-ipa"
    mkdir -p "$package_dir/Payload"
    cp -R "$native_dir/.build/device/Build/Products/Release-iphoneos/Hjortemosen.app" "$package_dir/Payload/"
    (cd "$package_dir" && /usr/bin/ditto -c -k --sequesterRsrc --keepParent Payload ../Hjortemosen-unsigned.ipa)
    ;;
  archive)
    : "${HJORT_TEAM_ID:?Set HJORT_TEAM_ID to the authorized paid Apple Developer team ID}"
    xcodebuild -project "$native_dir/Hjortemosen.xcodeproj" -scheme Hjortemosen -configuration Release -destination 'generic/platform=iOS' -archivePath "$native_dir/.build/Hjortemosen.xcarchive" DEVELOPMENT_TEAM="$HJORT_TEAM_ID" archive
    ;;
  *) echo 'Usage: build.sh simulator | device | archive' >&2; exit 2 ;;
esac
