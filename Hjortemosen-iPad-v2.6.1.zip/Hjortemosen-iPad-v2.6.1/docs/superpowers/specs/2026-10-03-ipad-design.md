# Hjortemosen på iPad

Brugeren har godkendt en installerbar iPad-version med automatisk filbackup og en mere overskuelig brugerflade. Eksisterende bookinger, betalinger, kalenderudskrift, kontraktskabeloner og håndskrift skal bevares. Safari-versionen skal fortsat virke på GitHub Pages.

## Brug

Fem hovedvalg: Overblik, Kalender, Ny booking, Dokumenter, Mere. Lejere og Blacklist bliver tydelige genveje under Mere. Overblikket prioriterer kommende bookinger og betalinger. Fotoet er mindre. Backup vises før standardpriser; sjældnere indstillinger kan foldes ud. Berøringsmål er mindst 44 px, og skærmene virker i begge iPad-retninger og på telefon.

## Installeret app

Swift/WKWebView indlæser appens medfølgende filer offline fra en fast loopbackadresse. Ingen ændring af sikkerhedsindstillinger eller private WebKit-flag. Native bro modtager kun egne hovedrammebeskeder. JSON-backup gemmes atomisk i appens Documents/Hjortemosen/seneste-backup.json, synlig i Filer. Op til ti tidligere versioner bevares. Ugyldige, ufuldstændige eller manglende primærdata må ikke erstatte en god kopi. Fejl vises tydeligt, og native kvittering kommer efter faktisk skrivning. Den aktive kontrakt og underskrift er med.

JavaScript-broen hedder HjortNative og bruger WK-handler hjortemosen: version 1, actions backup(snapshot), readLatest, openBackups, share(name,mimeType,base64), printCalendar(html). Svar er ok:true med relevante værdier eller ok:false/error. Native filbackup skal også forsøges, hvis browserens backupdatabase er utilgængelig. En helt tom native browsertilstand kan gendannes fra den gyldige seneste native kopi ved opstart.

Mail/Beskeder og print bruger native delings-/udskriftsmenuer. Ingen afsendelse sker automatisk. Safari bevarer de eksisterende menuer og browserbackups; den må aldrig påstå automatisk filbackup. Safari-data overføres med eksisterende komplet eksport/import. Sletning af den installerede app kan også slette dens lokale filer; dette oplyses i installationsvejledningen.

## Levering og bevis

Byg Xcode-projektet og lever kildepakken samt simulator-/enhedsbuild, hvor miljøet tillader det. Personlig Apple-signering og fysisk installation kræver brugerens konto/enhed; må ikke påstås gennemført uden bevis. Test native filskriver med rigtige midlertidige filer og webbro med fejl, køorden og manglende backend. Afprøv de ændrede skærme på den konkrete nye version. Udgiv webforbedringer til eksisterende GitHub Pages efter målrettet review og regressionstests.
